sudo echo "migrate_set_capability cuju-ft on" | sudo nc -U /[your work path]/vm1.monitor
sudo echo "migrate -d -c tcp:[backup side ip address ]:4441," | sudo nc -U /[your work path]/vm1.monitor
