#!/bin/sh
WORKSPACE=/your_work_path/data

sudo $WORKSPACE/reinsmodkvm.sh
sudo $WORKSPACE/set-net2.sh
sudo $WORKSPACE/set-vmft.sh

